package part1;

public class aaa extends bbb implements ccc{
    int a;

    public void ddd(){
        System.out.println("111");
    }
    @Override
    public void eee(){
        System.out.println("222");
    }
    @Override
    public void fff() {
        System.out.println("333");
    }


}

