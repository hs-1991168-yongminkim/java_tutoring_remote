package part1;

public abstract class bbb implements ccc{
    public abstract void eee();

}
