package part1;

public interface ccc {
    public void fff();

}
