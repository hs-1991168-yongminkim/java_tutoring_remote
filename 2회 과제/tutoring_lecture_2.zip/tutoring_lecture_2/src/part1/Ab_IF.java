package part1;

public interface Ab_IF {

    public abstract void ab_if_print();
}
