package part1;

public abstract class Abstract_CL implements Ab_IF{

    public abstract void abstract_print();


    @Override
    public void ab_if_print() {
        System.out.println("ab_if_print");
    }
}
