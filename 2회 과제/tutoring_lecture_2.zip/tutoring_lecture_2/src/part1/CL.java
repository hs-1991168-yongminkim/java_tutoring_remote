package part1;

public class CL extends Abstract_CL implements IF, IF2{

    public int a;
    protected int b;
    int c;
    private int d;

    @Override
    public void abstract_print() {
        System.out.println("abstract_print");
    }

    @Override
    public void IF_print() {
        System.out.println("IF_print");
    }

    @Override
    public void IF2_print() {
        System.out.println("IF2_print");
    }
}
