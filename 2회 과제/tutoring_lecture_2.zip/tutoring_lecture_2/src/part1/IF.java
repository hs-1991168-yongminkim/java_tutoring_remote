package part1;

public interface IF {

    public abstract void IF_print();
}
