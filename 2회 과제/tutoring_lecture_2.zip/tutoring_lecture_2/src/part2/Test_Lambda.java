package part2;

public class Test_Lambda {

    public Test_Lambda(Test_Annoymous TA) {
        TA.annoymous_print();
    }
}
