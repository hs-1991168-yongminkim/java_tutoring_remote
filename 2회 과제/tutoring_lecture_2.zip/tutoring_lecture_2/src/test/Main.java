package test;

import part1.Abstract_CL;
import part1.CL;
import part1.IF;
import part1.IF2;
import part2.Test_Annoymous;
import part2.Test_Lambda;

public class Main {

    public static void main(String[] args) {
        CL cl = new CL();

        cl.abstract_print();
        cl.ab_if_print();
        cl.IF_print();
        cl.IF2_print();

        Abstract_CL abstract_cl = new CL();
        abstract_cl.abstract_print();
        abstract_cl.ab_if_print();

        IF if_cl = new CL();
        if_cl.IF_print();

        IF2 if2 = new CL();
        if2.IF2_print();

        System.out.println("-----------------------------------------------------");

        // 익명 객체
        Test_Annoymous test_annoymous = new Test_Annoymous() {
            @Override
            public void annoymous_print() {
                System.out.println("test_annoymous");
            }
        };
        test_annoymous.annoymous_print();

        Test_Lambda test_lambda = new Test_Lambda(new Test_Annoymous() {
            @Override
            public void annoymous_print() {
                System.out.println("test_annoymous2");
            }
        });

        // 람다 적용
        Test_Lambda test_lambda1 = new Test_Lambda(() -> {
            System.out.println("test_lambda");
        });

    }
}
