package homework;

public abstract class abstractClass {
    public abstract void printWorld();
}
