package homework;

public class extendsClass {

}
