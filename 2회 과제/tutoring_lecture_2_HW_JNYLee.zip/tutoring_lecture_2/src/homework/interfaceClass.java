package homework;

public interface interfaceClass {
    abstract void printNew();
}
