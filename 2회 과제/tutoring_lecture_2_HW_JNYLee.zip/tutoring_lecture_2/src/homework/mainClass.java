package homework;

public class mainClass extends abstractClass implements interfaceClass{
    int number;

    String array;

    public void printHello() {
        System.out.println("mainClass.printHello : Hello");
    }

    @Override
    public void printWorld() {
        System.out.println("mainClass.printWorld(Override) : World");
    }

    @Override
    public void printNew() {
        System.out.println("mainClass.printNew(Override) :  New");
    }

}
