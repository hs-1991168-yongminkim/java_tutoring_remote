package part1;

public abstract class Abstract_CL implements Ab_IF{ // abstract : 추상 메소드를 포함한 클래스

    public abstract void abstract_print(); // 내용 없는 함수


    @Override
    public void ab_if_print() {
        System.out.println("ab_if_print");
    }
}
