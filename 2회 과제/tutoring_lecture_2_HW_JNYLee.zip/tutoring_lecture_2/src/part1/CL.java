package part1;

public class CL extends Abstract_CL implements IF, IF2{ // extends : 다른 클래스를 상속, implements : 구현

    public int a;
    protected int b;
    int c;
    private int d;

    @Override // 이미 구현된 함수를 재정의 한다.
    public void abstract_print() {
        System.out.println("abstract_print");
    }

    @Override
    public void IF_print() {
        System.out.println("IF_print");
    }

    @Override
    public void IF2_print() {
        System.out.println("IF2_print");
    }
}
