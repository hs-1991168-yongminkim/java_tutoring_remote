package part1;

public interface IF { // interface : 추상메소드만 작성

    public abstract void IF_print();
}
