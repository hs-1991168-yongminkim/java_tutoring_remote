package part1;

public interface IF2 {

    public abstract void IF2_print();
}
