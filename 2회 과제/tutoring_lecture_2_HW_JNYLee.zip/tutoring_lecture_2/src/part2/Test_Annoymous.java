package part2;

public interface Test_Annoymous {

    public abstract void annoymous_print();
}
