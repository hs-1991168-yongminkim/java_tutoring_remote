package part4;

public class test extends test2 implements test3{
    String a;
    int b;
    char c;

    public void print() {
        System.out.println("print() : Hello, World");
    }

    @Override
    public void aaa() {
        System.out.println("aaa() : Hi, World");
    }

    @Override
    public void test3_aaa() {
        System.out.println("test3_aaa() : New, World");
    }
}
