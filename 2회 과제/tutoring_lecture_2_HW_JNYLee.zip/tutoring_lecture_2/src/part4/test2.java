package part4;

public abstract class test2 {
    public abstract void aaa();

}
