package part4;

public interface test3 { // 내용 없는 함수만 사용하는 클래스
    public void test3_aaa();
}
