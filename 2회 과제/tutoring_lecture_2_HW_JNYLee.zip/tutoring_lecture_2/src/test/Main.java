package test;

import homework.abstractClass;
import homework.interfaceClass;
import homework.mainClass;

public class Main {

    public static void main(String[] args) { // 클래스 : 변수와 함수를 묶어서 만듦

        mainClass hello = new mainClass();
        hello.printHello();

        abstractClass world = new mainClass();
        world.printWorld();

        interfaceClass New = new mainClass();
        New.printNew();

        interfaceClass temp = new interfaceClass() {
          @Override
          public void printNew() {
              System.out.println("Main.temp.printNew(Override) : New");
          }
        };

        temp.printNew();
    }
}
