package minhyeok;

public class hyeokk extends minn{

    public hyeokk() {
        super("a");
        System.out.println("dd");
    }
}
