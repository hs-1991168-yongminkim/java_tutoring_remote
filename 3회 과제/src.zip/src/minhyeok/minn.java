package minhyeok;

public class minn {

        public String aa;

        protected String bb;

        String cc;

        private String dd;

        //public minn() {
        //System.out.println("bb");


        //}


    public minn() {
        System.out.println("vv");
    }

    public minn(String a) {
            this();
            System.out.println("_--__--_");
        }
    }

