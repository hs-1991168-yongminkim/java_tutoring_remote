package mini;

public class hyeok extends minmin{

    public hyeok() {
        super("a");
        System.out.println("dd");
    }
}
