package mini;

public class minmin {

    public String a;

    protected String b;

    String c;

    private String d;

    //public minmin() {
        //System.out.println("aa");


    //}

    public minmin(String a) {
        System.out.println("------");
    }
}
