package same;

public class Child extends Parent{

    public Parent p;

    public Child() {

        super();

        // this

        p = new Parent();


    }

}
