package same;

public class Same_package {

    public Parent p;


    public Same_package() {

        // this

        p = new Parent();



    }
}
