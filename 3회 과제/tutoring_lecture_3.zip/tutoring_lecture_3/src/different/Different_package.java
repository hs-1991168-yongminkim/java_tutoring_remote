package different;

import same.Parent;

public class Different_package {

    public Parent p;

    public Different_package() {

        // this

        p = new Parent();


    }
}
