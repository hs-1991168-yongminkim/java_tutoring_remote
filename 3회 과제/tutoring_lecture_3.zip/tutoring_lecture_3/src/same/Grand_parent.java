package same;

import same.Parent;

public class Grand_parent {

    public Parent p;

    public Grand_parent() {
        // this

        p = new Parent();


    }

}
