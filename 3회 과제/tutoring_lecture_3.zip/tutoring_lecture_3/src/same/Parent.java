package same;

import different.Child_different_package;

public class Parent extends Grand_parent {

    public String a;
    protected String b;
    String c;
    private String d;

    public String name = "Parent";

    public Parent() {
        this.a = "a";
        this.b = "b";
        this.c = "c";
        this.d = "d";
    }

    public Parent(String s) {
        this();
        this.name = s;

        Child_different_package cd = new Child_different_package();
        // cd.getD();
    }

    public String getA() { return a; }

    public String getB() {
        return b;
    }

    public String getC() { return c; }

    public String getD() {
        return d;
    }

    public void setA(String a) {
        this.a = a;
    }

    public void setB(String b) {
        this.b = b;
    }

    public void setC(String c) {
        this.c = c;
    }

    public void setD(String d) {
        this.d = d;
    }
}
