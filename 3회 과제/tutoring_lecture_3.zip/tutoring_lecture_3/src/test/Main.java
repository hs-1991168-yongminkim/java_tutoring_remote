package test;

import same.Child;
import same.Parent;

public class Main {

    public static void main(String[] args) {

        Child c = new Child();
        System.out.println(c.getD());

        c.setD("DD");
        System.out.println(c.getD());

        Parent p = new Parent();

    }
}
