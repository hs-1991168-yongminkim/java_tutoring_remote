package different;

import same.Parent;

public class Child_different_package extends Parent {

    public Parent p;

    public Child_different_package() {

        super();

        // this


        p = new Parent();



    }
}
