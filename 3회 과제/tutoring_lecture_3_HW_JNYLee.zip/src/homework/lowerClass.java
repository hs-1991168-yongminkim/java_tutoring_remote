package homework;

public class lowerClass extends upperClass{

    public lowerClass(String inputStr) {
        super(inputStr);
        System.out.println("[lowerClass] after upperClass()");
    }
}
