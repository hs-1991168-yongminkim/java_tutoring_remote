package homework;

public class upperClass {
    String str1;
    public String str2;
    private String str3;
    protected String str4;

    String str5 = "str5";

    public upperClass() {
        this.str1 = "str1";
        this.str2 = "str2";
        this.str3 = "str3";
        this.str4 = "str4";

        System.out.println("[upperClass] String 1: " + str1);
        System.out.println("[upperClass] String 2: " + str2);
        System.out.println("[upperClass] String 3: " + str3);
        System.out.println("[upperClass] String 4: " + str4);
    }

    public upperClass(String tempStr) {
        this();
        this.str5 = tempStr;
        System.out.println("[upperClass] String 5: "+ str5);
    }
}
