package same;

public class Child extends Parent{

    public Parent p;

    public Child() {

        super();

        // this : 상속받으면 사용가능

        p = new Parent();


    }

}
