package same;

import same.Parent;

public class Grand_parent {

    public Parent p;

    public Grand_parent() {
        // this : Parent()를 상속하지 않아서 않뜸

        p = new Parent();


    }

}
