package same;

import different.Child_different_package;

// 접근지정자
public class Parent extends Grand_parent {

    // 변경 가능
    public String a;

    // 같은 폴더 내에서 만 사용 가능 상속을 받으면 사용할 수 있다.
    protected String b;
    // 디폴트 : 같은 폴더 내에서 사용가능
    String c;
    // 파일 내부에서만 변경 가능
    private String d;

    public String name = "Parent";

    public Parent() {
        this.a = "a";
        this.b = "b";
        this.c = "c";
        this.d = "d";
    }

    public Parent(String s) {
        this();
        this.name = s;

        Child_different_package cd = new Child_different_package();
        // cd.getD();
    }

    public String getA() { return a; }

    public String getB() {
        return b;
    }

    public String getC() { return c; }

    public String getD() {
        return d;
    }

    public void setA(String a) {
        this.a = a;
    }

    public void setB(String b) {
        this.b = b;
    }

    public void setC(String c) {
        this.c = c;
    }

    public void setD(String d) {
        this.d = d;
    }
}
