package test;

import homework.lowerClass;

public class Main {

    public static void main(String[] args) {

        lowerClass lC = new lowerClass("inputString");
    }
}
