import prac1.ex1;
import prac2.ex2;
public class Main {
    public static void main(String[] args) {
        System.out.println("Hello world!");

        ex1 a = new ex1();
        //ex2 b = new ex2("a");
    }
}