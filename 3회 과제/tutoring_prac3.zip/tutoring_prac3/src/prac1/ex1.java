package prac1;
import prac2.ex2;
public class ex1 extends ex2 {   //child

    public ex1() {
        super("a");
        System.out.println("111");
    }
}
