package prac2;

public class ex2 {   //parents
    public String a;
    protected String b;
    String c;
    private String d;

//    public ex2() {
//        System.out.println("222");
//    }

    public ex2(String a) {
        System.out.println("333");
    }
}
