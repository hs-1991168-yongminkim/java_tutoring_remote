package example_static;

import human.Person;

public class Print {
    public static int time = 0;

    public static void print(Person p) {
        System.out.println("time = " + time);
        System.out.println("height = " + p.height);
        System.out.println("weight = " + p.weight);
        time += 1;
    }

    public Print() {
        time += 1;
        System.out.println(time);
    }

}
