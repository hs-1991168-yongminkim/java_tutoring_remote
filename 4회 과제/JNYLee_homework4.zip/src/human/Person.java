package human;

public class Person implements Behavior {
    public int height;
    public  int weight;
    protected int code;
    String name;

    public Person(int height, int weight) {
        this.height = height;
        this.weight = weight;
    }

    @Override
    public void run() {
        this.weight += 1;
        this.height += 1;
    }
}
