package test;

import example_static.Print;
import human.Person;
import human.Student;

public class Main {
    public static void main(String[] args) {
        Person p = new Person(100, 200);
        p.run();
        Print.print(p);

        Person stu = new Student(300, 400);
        stu.run();
        Print.print(stu);

        Person any = new Person(500, 600) {
            @Override
            public void run() {
                this.height += 2;
                this.weight += 2;
            }
        };
        any.run();
        Print.print(any);

        Student student = new Student(700, 800); 
        student.study(); // Person은 안됨

    }
}