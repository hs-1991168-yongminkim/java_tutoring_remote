package human;

public interface Behavior {
}
