package human;

public interface Behavior {
    public void run();
}
