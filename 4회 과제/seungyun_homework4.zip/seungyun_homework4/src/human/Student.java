package human;


public class Student extends Person {
    public int score = 0;
    public Student(int height, int weight)
    {
        super(height, weight);
        this.code = 10;
        this.name = "a";

    }
    public void study() {
        this.score += 1;
        System.out.println("score = " + this.score);
    }
}
