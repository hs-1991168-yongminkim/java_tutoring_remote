package generic;

public class CoffeeMachine {
    public void print(String a){

    }

    public <T> Coffee makeCoffee(T material) {
        return new Coffee(material);
    }

}
