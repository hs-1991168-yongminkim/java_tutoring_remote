package no_generic;

public class After_Generic <T> {
    T code;
    public After_Generic(T code) {this.code = code; }
    public T getCode() { return code; }
    public void setCode(T code) { this.code = code; }

}
