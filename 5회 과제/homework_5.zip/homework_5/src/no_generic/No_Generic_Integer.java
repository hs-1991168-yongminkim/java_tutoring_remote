package no_generic;

public class No_Generic_Integer {

    private int code;
    public No_Generic_Integer(int code) {this.code = code;}

    public int getCode() {return code;}
    public void setCOde(int code) {this.code = code;}
}
