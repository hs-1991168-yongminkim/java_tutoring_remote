package wild_card;

public class Wild_Card <T extends Parent> {
    public Wild_Card() {
        System.out.println("success");
    }

    public void print(Wild<? super Parent> d) {
        System.out.println(d.getVariable());
    }

}
