package generic;

public class Box<M, I> {

    private M material;
    private I item;

    public Box() {
    }

    public Box(M material, I item) {
        this.material = material;
        this.item = item;
    }

    public M getMaterial() {
        return material;
    }

    public void setMaterial(M material) {
        this.material = material;
    }

    public I getItem() {
        return item;
    }

    public void setItem(I item) {
        this.item = item;
    }
}
