package generic;

public class CoffeeMachine {

    public <T> Coffee makeCoffee(T material) {

        return new Coffee(material);
    }
}
