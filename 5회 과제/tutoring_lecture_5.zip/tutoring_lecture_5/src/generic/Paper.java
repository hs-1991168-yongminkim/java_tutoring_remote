package generic;

public class Paper {
}
