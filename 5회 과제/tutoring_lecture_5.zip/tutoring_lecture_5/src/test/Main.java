package test;

import generic.Box;
import generic.Coffee;
import generic.CoffeeMachine;
import no_generic.*;
import wild_card.*;

import java.awt.print.Paper;

public class Main {

    public static void main(String[] args) {


        No_Generic_Integer no_generic_integer = new No_Generic_Integer(1);
        System.out.println(no_generic_integer.getCode());

        No_Generic_String no_generic_string = new No_Generic_String("a");
        System.out.println(no_generic_string.getCode());

        After_Generic<Integer> after_generic = new After_Generic<>(2);
        System.out.println(after_generic.getCode());

        After_Generic<String> after_generic1 = new After_Generic<>("b");
        System.out.println(after_generic1.getCode());


        CoffeeMachine coffeeMachine = new CoffeeMachine();

        Coffee<Integer> coffee = coffeeMachine.makeCoffee(3);
        coffee.print_any();

        Coffee<String> coffee1 = coffeeMachine.makeCoffee("c");
        coffee1.print_any();

        Box<Integer, String> box = new Box<>();
        Box<Integer, String> box1 = new Box<>(4, "d");
        System.out.println(box1.getItem() + " " + box1.getMaterial());

        Box<Paper, String> box_1 = new Box<Paper, String>();
        Box<Paper, String> box_2 = new Box<>();
        Box box_3 = new Box(); // Object로 간주

        Wild_Card<Child> wild_card = new Wild_Card<>();

//        Wild<String> wild = new Wild<>("5");
//        wild_card.print(wild);

        Wild<Grand_Parent> wild1 = new Wild<>();
        wild_card.print(wild1);

    }
}
