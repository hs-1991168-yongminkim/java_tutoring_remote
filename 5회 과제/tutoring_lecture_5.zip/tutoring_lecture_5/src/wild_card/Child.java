package wild_card;

public class Child extends Parent {
}
