package wild_card;

public class Grand_Parent {
}
