package wild_card;

public class Parent extends Grand_Parent{
}
