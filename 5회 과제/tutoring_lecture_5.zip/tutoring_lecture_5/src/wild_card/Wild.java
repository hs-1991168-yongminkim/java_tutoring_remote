package wild_card;

public class Wild<T> {

    T variable;

    public Wild() {

    }

    public Wild(T variable) {
        this.variable = variable;
    }

    public T getVariable() {
        return variable;
    }
}
