package generic;

public class Coffee<T> {

    T any;

    public Coffee(T a) {
        any = a;
    }

    public void print_any() {
        System.out.println(any);
    }
}
