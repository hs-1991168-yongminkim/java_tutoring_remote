package no_generic;

public class No_Generic_String {
    private String code;

    public No_Generic_String(String code) {this.code = code;}

    public String getCode() {return code;}

    public void setCode(String code) {this.code = code;}
}
