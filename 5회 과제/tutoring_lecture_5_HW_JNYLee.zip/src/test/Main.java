package test;

import no_generic.After_Generic;
import no_generic.No_Generic_Integer;
import no_generic.No_Generic_String;
import wild_card.*;

import java.awt.print.Paper;

public class Main {

    public static void main(String[] args) {

        No_Generic_Integer a = new No_Generic_Integer(1);

        No_Generic_String b = new No_Generic_String("1");

        After_Generic<String> c = new After_Generic<>("2");

        System.out.println(); // sout 단축키

    }
}
