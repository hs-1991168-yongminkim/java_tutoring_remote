package wild_card;

public class Wild_Card <T extends Parent>{

    public Wild_Card() {
        System.out.println("Success");
    }

    public void print(Wild<? super Parent> w) { // ? super : Parent를 상속하는 클래스의 형식만을 받겠다.
        System.out.println(w.getVariable());
    }
}
