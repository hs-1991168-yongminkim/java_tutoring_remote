package test;

import java.util.*;

public class Main {
    public static void main(String[] args) {
        for(int i = 0; i < 5; i++){
            System.out.println("---");
        }
        int[] a = new int[5];
        for(int j = 0; j <5; j++){
            a[j] = 3;
        }
        for(int b : a){
            System.out.println(b);
        }
        String[] string = new String[5];
        for(int k = 0; k<5; k++){
            string[k] = "abc";
        }
        for(String c : string){
            System.out.println(c);
        }

        Integer integer = new Integer(4);
        ArrayList<Integer> hh = new ArrayList<Integer>();
        System.out.println(hh.size());
        hh.add(4);
        hh.add(5);
        System.out.println(hh.size());
        System.out.println(hh);
        String strings = new String();
        ArrayList<String> bb = new ArrayList<String>();
        System.out.println(bb.size());
        bb.add("5");
        bb.add("9");
        bb.add("7");
        System.out.println(bb.size());
        System.out.println(bb);

        Map<Integer, String> map = new HashMap<>();
        map.put(1, "r");
        map.put(2, "g");
        for(Integer h:map.keySet()){
            System.out.println(h + " " + map.get(h));
        }

        Set<Integer> set = new HashSet<>();
        set.add(7);
        set.add(8);

        for(Integer c : set){
            System.out.println(c);
        }

    }
}