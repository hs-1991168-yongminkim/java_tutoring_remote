package test;

import java.util.*;

public class Main {

    public static void main(String[] args) {

        // 정적 배열 String
        String[] strings = new String[5];

        for (int i = 0; i < 5; i += 1) {
            strings[i] = "a";
        }

        for (String s: strings) {
            System.out.print(s);
        }

        System.out.println();

        int j = 0;
        while (j < 5) {
            System.out.print(strings[j]);
            j += 1;
        }

        System.out.println();

        // 정적 배열 int
        int[] ints = new int[5];

        for (int i = 0; i < 5; i += 1) {
            ints[i] = i;
        }

        for (int a: ints) {
            System.out.print(a);
        }

        System.out.println();

        // Integer는 Wrapper 클래스
        // Wrapper 클래스란 int, long 등 클래스를 정의하지 않은 자료형에 대한 함수, 변수 등을 지원하는 클래스
        Integer integer = new Integer(1);
        int String_to_int = Integer.parseInt("10");


        // 동적 배열 ArrayList
        ArrayList<Integer> arrayList = new ArrayList<Integer>();
        System.out.println(arrayList.size());

        arrayList.add(2);
        arrayList.add(1);

        System.out.println(arrayList.size());

        // List 인터페이스에 할당 가능
        List<String> list = new ArrayList<>();
        list.add("3");
        list.add("4");

        System.out.println(list.size());
        list.clear();

        System.out.println(list.size());

        for (int a: arrayList) {
            System.out.println(a);
        }

        Collections.sort(arrayList);

        for (int a: arrayList) {
            System.out.println(a);
        }

        // map 인터페이스
        // 대응
        Map<Integer, String> map = new HashMap<>();
        map.put(1, "a");
        map.put(2, "b");

        for (Integer k: map.keySet()) {
            System.out.println(k + " " + map.get(k));
        }

        // set 인터페이스
        // 집합
        Set<Integer> set = new HashSet<>();
        set.add(5);
        set.add(6);

        for (Integer i : set) {
            System.out.println(i);
        }

    }
}
