package test;

import java.util.*;

public class Main {

    public static void main(String[] args) {

        for(int i = 0; i < 5; i++) {
            System.out.println("---");
        }

        int[] a = new int[5];

        for(int i = 0; i < 5; i++) {
            a[i] = i;
        }

        int index = 0; // 배열 인덱스

        for(int i : a) {
            System.out.println("a[" + index + "] : " + a);
            index++;
        }

        String[] b = new String[6];

        for(int i = 0; i < 6; i++) {
            b[i] = "a";
        }


        index = 0;
        for(String i : b) {
            System.out.println("b[" + index + "] : " + i);
            index++;
        }

        ArrayList<Integer> c = new ArrayList<>();
        c.add(3);
        c.add(-1);
        c.add(999999999);

        index = 0;
        for(int i : c) {
            System.out.println("c[" + index + "] : " + i);
            index++;
        }

        List<String> d = new ArrayList<>();
        d.add("s");
        d.add("o");
        d.add("r");
        d.add("t");
        d.add("?");

        Collections.sort(d);

        index = 0;
        for(String i : d) {
            System.out.println("d[" + index + "] : " + i);
            index++;
        }

        Map<Integer, String> e = new HashMap<>();
        e.put(1, "first");
        e.put(2, "second");
        e.put(3, "third");

        for(int i : e.keySet()) {
            System.out.println("e-"+ i+ " : " + e.get(i));
        }

        Set<Integer> f = new HashSet<>();
        f.add(1);
        f.add(0);
        f.add(-1);

        for(int i : f) {
            System.out.println("f[" + index + "] : " + i);
        }


    }
}
