package test;

import thread.runnable_class;
import thread.runnable_for_class;
import thread.thread_class;

public class Main {
    public static void main(String[] args) {

        thread_class a = new thread_class(2071013);
        a.start();

        runnable_class b = new runnable_class(1);
        Thread c = new Thread(b);
        c.start();

        runnable_for_class d = new runnable_for_class();
        Thread e = new Thread(d);
        e.start();


        Thread f = new Thread(new Runnable() {
            @Override
            public void run() {
                for(int i = 0; i < 10; i++) {
                    System.out.println("OOO");
                    try {
                        Thread.sleep(1000);
                    }catch (Exception e) {
                        throw new RuntimeException();
                    }
                }
            }
        });
        f.start();
    }
}