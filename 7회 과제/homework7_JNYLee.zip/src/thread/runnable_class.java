package thread;

public class runnable_class implements Runnable {

    int grade;

    public runnable_class(int grade) {
        this.grade = grade;
    }

    @Override
    public void run() {
        System.out.println("나의 학년 : " + grade);
    }
}
