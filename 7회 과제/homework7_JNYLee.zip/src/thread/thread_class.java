package thread;

public class thread_class extends Thread{
    int number;

    public thread_class(int number) {
        this.number = number;
    }

    @Override
    public void run() {
        System.out.println("나의 학번: " + number);
    }
}
