package test;

import thread.aaa;
import thread.bbb;
import thread.ccc;

public class Main {
    public static void main(String[] args) {
       aaa abc = new aaa(2291073);
       abc.start();

       bbb bac = new bbb(1);
       Thread thread = new Thread(bac);
       thread.start();

       ccc cab = new ccc();
       Thread cc = new Thread(cab);
       cc.start();

       Thread c = new Thread(new Runnable() {
           @Override
           public void run() {
               System.out.println(7);
           }
       });
       c.start();
    }
}