package thread;

public class aaa extends Thread{


    int num;
    public aaa(int a){
        this.num = a;
    }

    @Override
    public void run() {
        System.out.println(2291073);
    }
}
