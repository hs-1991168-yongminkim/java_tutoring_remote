package thread;

public class bbb implements Runnable {

    int grade;

    public bbb(int grade) {
        this.grade = grade;
    }

    @Override
    public void run() {
        System.out.println(1);
    }
}
