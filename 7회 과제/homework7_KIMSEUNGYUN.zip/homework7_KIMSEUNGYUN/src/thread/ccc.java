package thread;

public class ccc implements Runnable{
    @Override
    public void run() {
        for(int i = 0; i<10; i++){

            System.out.println("---");
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
        }
    }
}
