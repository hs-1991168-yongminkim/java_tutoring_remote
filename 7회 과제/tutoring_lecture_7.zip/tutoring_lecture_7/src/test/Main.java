package test;

import thread.Runnable_Ex_1;
import thread.Thread_Ex_1;
import thread.Try_Catch_Sleep;

public class Main {

    public static void main(String[] args) {

//        Thread_Ex_1 thread_ex_1 = new Thread_Ex_1("1");
//        thread_ex_1.start();
//
//        Thread_Ex_1 thread_ex_11 = new Thread_Ex_1("2");
//        thread_ex_11.start();
//
//        Thread thread_ex = new Thread() {
//            @Override
//            public void run() {
//                for (int i = 0; i < 10; i += 1) {
//                    System.out.println("kkk");
//                }
//            }
//        };
//        thread_ex.start();
//
//        Runnable_Ex_1 runnable_ex_1 = new Runnable_Ex_1();
//        Thread thread = new Thread(runnable_ex_1);
//        thread.start();
//
//        Thread thread1 = new Thread(new Runnable() {
//            @Override
//            public void run() {
//                for (int i = 0; i < 10; i += 1) {
//                    System.out.println("4printed!");
//                }
//            }
//        });
//        thread1.start();

//        Try_Catch_Sleep try_catch_sleep = new Try_Catch_Sleep();
//        Thread thread_try = new Thread(try_catch_sleep);
//        thread_try.start();


    }
}
