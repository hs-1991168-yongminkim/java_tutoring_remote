package thread;

import java.nio.channels.AsynchronousByteChannel;

public class Runnable_Ex_1 implements Runnable {

    @Override
    public void run() {

        for (int i = 0; i < 10; i += 1) {
            System.out.println("3printed!");
        }


    }

}
