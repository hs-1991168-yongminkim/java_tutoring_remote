package thread;

public class Thread_Ex_1 extends Thread {

    String name;

    public Thread_Ex_1(String s) {
        this.name = s;
    }

    @Override
    public void run() {
        // super.run();

        for (int i = 0; i < 10; i += 1) {
            System.out.println(name + "printed!");
        }

    }
}
