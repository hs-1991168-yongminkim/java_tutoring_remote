package thread;

public class Try_Catch_Sleep implements Runnable{
    @Override
    public void run() {

        for (int i = 0; i < 10; i += 1) {
            System.out.println("a");

            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }

            System.out.println();
        }


    }
}
