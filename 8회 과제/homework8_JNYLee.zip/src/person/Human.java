package person;

public interface Human {
    public void print();
}
