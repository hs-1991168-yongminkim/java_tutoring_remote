package person;

import java.util.ArrayList;

public class Professor implements Human{
    ArrayList<Student> a = new ArrayList<>();

    public void add_Student(Student s) {
        a.add(s);
    }

    @Override
    public void print() {
        for (Student s:
             a) {
            System.out.println("이름 : " + s.name + "점수 : " + s.score);
        }
    }
}
