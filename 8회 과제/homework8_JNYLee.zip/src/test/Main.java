package test;

import person.Professor;
import person.Student;
import thread.Runnable_1;
import thread.Thread_1;

public class Main {
    public static void main(String[] args) {
        Student b = new Student(99, "기기기");
        Student c = new Student(10, "나나나");

        Professor d = new Professor();

        d.add_Student(b);
        d.add_Student(c);


        Thread_1 t1 = new Thread_1(d);
        t1.start();

        Runnable_1 r1 = new Runnable_1(d);
        Thread t = new Thread(r1);
        t.start();

        Thread tt = new Thread(new Runnable() {
            @Override
            public void run() {
                System.out.println("~~~");
                d.print();
            }
        });
        tt.start();

    }
}