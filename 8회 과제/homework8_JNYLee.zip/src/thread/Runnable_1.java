package thread;

import person.Professor;

public class Runnable_1 implements Runnable{

    Professor p;

    public Runnable_1(Professor p) {
        this.p = p;
    }

    @Override
    public void run() {
        System.out.println("///");
        p.print();
    }
}
