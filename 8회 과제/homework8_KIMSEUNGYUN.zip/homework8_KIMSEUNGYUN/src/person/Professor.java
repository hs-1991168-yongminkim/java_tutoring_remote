package person;

import java.util.ArrayList;

public class Professor implements Human {

    ArrayList<Student> a = new ArrayList<>();

    public void add_Student(Student s){
        a.add(s);

    }

    @Override
    public void print() {

        for (Student b:a) {
            b.print();
        }
    }
}
