package test;
import person.Professor;
import person.Student;
import thread.Runnable_1;
import thread.Thread_1;

public class Main {
    public static void main(String[] args) {
        Student d = new Student(10,"가나");
        Student e = new Student(10,"다라");

        Professor f = new Professor();

        f.add_Student(d);
        f.add_Student(e);

        Thread_1 thread = new Thread_1(f);
        thread.start();

        Runnable_1 runnable = new Runnable_1(f);
        Thread read = new Thread(runnable);
        read.start();


        Runnable g = new Runnable() {
            @Override
            public void run() {
                System.out.println("~~~");
                f.print();
            }
        };
        Thread h = new Thread(g);
        h.start();

    }
}