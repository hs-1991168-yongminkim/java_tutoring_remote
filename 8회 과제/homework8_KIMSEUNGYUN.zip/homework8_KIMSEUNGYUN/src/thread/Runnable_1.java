package thread;

import person.Professor;

public class Runnable_1 implements Runnable{

    Professor p;
    public Runnable_1(Professor c){
        this.p = c;
    }

    @Override
    public void run() {
        System.out.println("///");
        p.print();
    }
}
