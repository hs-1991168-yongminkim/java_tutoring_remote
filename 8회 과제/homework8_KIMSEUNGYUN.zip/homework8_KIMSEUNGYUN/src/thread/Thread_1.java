package thread;

import person.Professor;

public class Thread_1 extends Thread {

    Professor p;

    public Thread_1(Professor s){
        this.p = s;
    }
    public void run(){
        System.out.println("===");
        p.print();
    }


}
