package event;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.ArrayList;

public class LoginEvent {

	public static LoginEvent LE = new LoginEvent();
	
	public ArrayList<String> id_list = new ArrayList();
	public ArrayList<String> pass_list = new ArrayList();
	public ArrayList<Integer> score_list = new ArrayList();
	
	private LoginEvent() {
		try {
			set_data();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void set_data() throws IOException {
		
		// 기존 arraylist 전부 초기화
		id_list.clear();
		pass_list.clear();
		score_list.clear();
		
		BufferedReader reader = new BufferedReader(new FileReader("member.txt"));
		
		String str;
	    while ((str = reader.readLine()) != null) {
	    	
	    	String[] list = str.split("-");
	    	id_list.add(list[0]);
	    	pass_list.add(list[1]);
	        score_list.add(Integer.parseInt(list[2]));
	    }
	    reader.close();
		
	    // System.out.println(id_list.size());
	    
	}
	
	public boolean is_Possible_Login(String id, String pass) throws IOException{
		
		for (int i = 0; i < id_list.size(); i += 1) {
			if (id_list.get(i).equals(id) && pass_list.get(i).equals(pass)) return true;
		}
	    return false;
		
	}
	
	public boolean is_Possible_join(String id) throws IOException{
	
		
		for (int i = 0; i < id_list.size(); i += 1) {
			if (id_list.get(i).equals(id)) return true;
		}
	    return false;
		
	}
	
}
