package event;

import java.awt.Color;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JButton;
import javax.swing.JLabel;

import frame.GameFrame;
import music.boommusic;
import music.devilmusic;
import music.fishmusic;
import music.shieldmusic;
import music.tornadomusic;
import panel.ScorePanel;
import panel.TimerPanel;
import thread.Item_thread;
import thread.Timer_thread;

public class MouseClick extends MouseAdapter {

	
	public void mousePressed(MouseEvent e) {
		
		JLabel la = (JLabel)e.getSource();
		la.setIcon(null);
		
		
		JButton score_btn = ScorePanel.score_btn;
		int present_score = Integer.parseInt(score_btn.getText());
		
		JButton shield_btn = ScorePanel.shield_btn;
		int count_shield = Integer.parseInt(shield_btn.getText());
		
		JButton state_btn = ScorePanel.state_btn;
		
		JLabel[][] label_arr = Item_thread.label_arr;
		
		if (la.getText() == "f") {
			Thread fishmusic=new fishmusic();
			fishmusic.start();
			
			if (GameFrame.GF.get_devil_mode() == false) {
				GameFrame.GF.set_happy(true);
				present_score += 1;
			}
			else {
				if (count_shield > 1) count_shield -= 1;
				else present_score -= 5;
			}
		}
		else if (la.getText() == "b") {
			Thread boommusic=new boommusic();
			boommusic.start();
			
			if (GameFrame.GF.get_devil_mode() == false) {
				if (count_shield > 0) {
					count_shield -= 1;
				}
				else {
					GameFrame.GF.set_happy(false);
					present_score -= 5;
				}
			}
			else {
				present_score += 1;
			}
		}
		else if (la.getText() == "t") {
			Thread tornadomusic=new tornadomusic();
			tornadomusic.start();
			
			for (int i = 0; i < label_arr.length; i += 1) {
				for (int j = 0; j < label_arr.length; j += 1) {
					label_arr[i][j].setIcon(null);
				}
			}
		}
		else if (la.getText() == "d") {
			Thread devilmusic=new devilmusic();
			devilmusic.start();
			
			
			if (GameFrame.GF.get_devil_mode() == false) {
				GameFrame.GF.set_devil_mode(true);
				state_btn.setText("악마");
				
				state_btn.setForeground(Color.RED);
				GameFrame.GF.set_devil_time(10);
			}
			
		}
		
		else if (la.getText() == "s") {
			Thread shieldmusic=new shieldmusic();
			shieldmusic.start();
			
			if (GameFrame.GF.get_devil_mode() == false && count_shield < 10) count_shield += 1;
		}
		
		score_btn.setText(String.valueOf(present_score));
		shield_btn.setText(String.valueOf(count_shield));
		la.setText("_");
		la.setIcon(null);
	}
	
}
