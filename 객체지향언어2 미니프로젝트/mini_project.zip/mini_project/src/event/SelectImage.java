package event;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JTextField;

import frame.LoginFrame;

public class SelectImage extends MouseAdapter {
	
	int index;
	String link;
	JTextField jt;
	
	
	public SelectImage(int i, String str, JTextField field) {
		this.index = i;
		this.link = str;
		this.jt = field;
	}
	
	public void mousePressed(MouseEvent e) {
		for (int i = 0; i < LoginFrame.LF.is_selected_arr.length; i += 1) {
			LoginFrame.LF.is_selected_arr[i] = false;
		}
		
		LoginFrame.LF.is_selected_arr[index] = true;
		
		for (int i = 0; i < LoginFrame.LF.is_selected_arr.length; i += 1) {
			if (LoginFrame.LF.is_selected_arr[i] == true) {
				LoginFrame.LF.label_image_list[i].setIcon(LoginFrame.LF.sel_icon_arr_change[i]);
			}
			else {
				LoginFrame.LF.label_image_list[i].setIcon(LoginFrame.LF.icon_arr_change[i]);
			}
		}
		
		jt.setText(link);
	}
}
