package frame;

import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

import music.homemusic;


public class ExFrame extends JFrame{
	
	public static ExFrame ExF;
	
	private MyPanel panel = new MyPanel();
	JLabel la = new JLabel();
	
	public ExFrame() {
		super("게임 준비");
		setSize(850,550);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setContentPane(panel);
		setLayout(null);
		
		ImageIcon f = new ImageIcon(getClass().getClassLoader().getResource("fish.png"));
		ImageIcon b = new ImageIcon(getClass().getClassLoader().getResource("bomb.png"));
		ImageIcon t = new ImageIcon(getClass().getClassLoader().getResource("tornado.png"));
		ImageIcon d = new ImageIcon(getClass().getClassLoader().getResource("devil.png"));
		ImageIcon shield = new ImageIcon(getClass().getClassLoader().getResource("shield.png"));
		
		Image img=f.getImage(); 
		Image changeImg = img.getScaledInstance(50, 50, Image.SCALE_DEFAULT);
		ImageIcon fishimg = new ImageIcon(changeImg);
		
		Image img1=b.getImage(); 
		Image changeImg1 = img1.getScaledInstance(50, 50, Image.SCALE_DEFAULT);
		ImageIcon boomimg = new ImageIcon(changeImg1);
		
		Image img2=t.getImage(); 
		Image changeImg2 = img2.getScaledInstance(50, 50, Image.SCALE_DEFAULT);
		ImageIcon tornadoimg = new ImageIcon(changeImg2);
		
		Image img3=d.getImage(); 
		Image changeImg3 = img3.getScaledInstance(50, 50, Image.SCALE_DEFAULT);
		ImageIcon devilimg = new ImageIcon(changeImg3);
		
		Image img4=shield.getImage(); 
		Image changeImg4 = img4.getScaledInstance(50, 50, Image.SCALE_DEFAULT);
		ImageIcon shield_img = new ImageIcon(changeImg4);
		
		
		
		JLabel la=new JLabel("가이드북 : 게임 설명");
		la.setFont(new Font("Serif", Font.BOLD, 30));
		
		//la.setFont(la.getFont().deriveFont(100));
		la.setLocation(30, 20);
		la.setSize(300, 50);
		add(la);
		
		JLabel la1 = new JLabel();
		la1.setText("마우스로 클릭해 물고기를 사냥하세요!");
		la1.setFont(new Font("Serif", Font.PLAIN, 20));
		la1.setSize(400, 50);
		la1.setLocation(30, 80);
		add(la1);
		
		JLabel fishlabel=new JLabel(fishimg);
		fishlabel.setLocation(17, 120);
		fishlabel.setSize(100, 100);
		add(fishlabel);
		JLabel fishEx = new JLabel("물고기  :  점수 + 1");
		fishEx.setFont(new Font("Serif", Font.PLAIN, 20));
		fishEx.setLocation(150, 120);
		fishEx.setSize(400, 100);
		add(fishEx);
		
		
		JLabel boomlabel=new JLabel(boomimg);
		boomlabel.setLocation(17, 190);
		boomlabel.setSize(100, 100);
		add(boomlabel);
		JLabel boomEx = new JLabel("폭탄  :  점수 - 5");
		boomEx.setFont(new Font("Serif", Font.PLAIN, 20));
		boomEx.setLocation(150, 190);
		boomEx.setSize(400, 100);
		add(boomEx);
		
		
		JLabel tornadolabel=new JLabel(tornadoimg);
		tornadolabel.setLocation(17, 260);
		tornadolabel.setSize(100, 100);
		add(tornadolabel);
		JLabel tornadoEx = new JLabel("토네이도  :  맵에 표시된 모든 아이템 삭제");
		tornadoEx.setFont(new Font("Serif", Font.PLAIN, 20));
		tornadoEx.setLocation(150, 260);
		tornadoEx.setSize(400, 100);
		add(tornadoEx);
		
		
		JLabel devillabel=new JLabel(devilimg);
		devillabel.setLocation(17, 340);
		devillabel.setSize(100, 100);
		add(devillabel);
		JLabel devilEx = new JLabel("악마화  :  일정 시간 동안 효과 반대 적용. 물고기 -5   폭탄 + 1");
		devilEx.setFont(new Font("Serif", Font.PLAIN, 20));
		devilEx.setLocation(150, 340);
		devilEx.setSize(600, 100);
		add(devilEx);
		
		
		JLabel shieldlabel=new JLabel(shield_img);
		shieldlabel.setLocation(17, 420);
		shieldlabel.setSize(100, 100);
		add(shieldlabel);
		JLabel shieldEx = new JLabel("방패  :  방패 개수만큼 점수 감소 차단");
		shieldEx.setFont(new Font("Serif", Font.PLAIN, 20));
		shieldEx.setLocation(150, 420);
		shieldEx.setSize(400, 100);
		add(shieldEx);
		
		
		JButton nextBtn = new JButton("돌아가기");
		nextBtn.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
					homemusic.clip.stop();
				
					setVisible(false);
					HomeFrame.HF = new HomeFrame();
			}
		});
		nextBtn.setSize(100, 50);
		nextBtn.setLocation(720, 450);
		add(nextBtn);
		
		setLocationRelativeTo(null);
		setVisible(true);
	}

	class MyPanel extends JPanel {
		ImageIcon backgroundicon = new ImageIcon(getClass().getClassLoader().getResource("pink.jpg"));
		Image background = backgroundicon.getImage();
		
		public void paintComponent(Graphics g) {
			super.paintComponent(g);
			
			// 이미지를 패널 크기로 조절하여 그린다
			g.drawImage(background, 0, 0, getWidth(), getHeight(), this);
		}	
	}
}
