package frame;

import java.awt.BorderLayout;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

import event.LoginEvent;
import music.playmusic;
import object.Player;
import panel.CenterPanel;
import panel.NorthPanel;
import panel.ScorePanel;
import panel.TimerPanel;
import thread.Item_thread;
import thread.Timer_thread;

public class GameFrame extends JFrame {
	
	private static Player player;
	
	public static GameFrame GF;
	
	private boolean game_start;
	private boolean game_stop;
	
	private boolean happy;
	private boolean devil_mode;
	private int devil_time;
	
	public static JPanel map_panel;
	
	public boolean get_game_start() {
		return this.game_start;
	}
	
	public boolean get_game_stop() {
		return this.game_stop;
	}
	
	public boolean get_happy() {
		return this.happy;
	}
	
	public boolean get_devil_mode() {
		return this.devil_mode;
	}
	
	public int get_devil_time() {
		return this.devil_time;
	}
	
	
	public void set_game_start(boolean g) {
		this.game_start = g;
	}
	
	public void set_game_stop(boolean g) {
		this.game_stop = g;
	}
	
	public void set_happy(boolean h) {
		this.happy = h;
	}
	
	public void set_devil_mode(boolean d) {
		this.devil_mode = d;
	}
	
	public void set_devil_time(int d) {
		this.devil_time = d;
	}
	
	
	public GameFrame() {
		super("게임 화면");
		this.set();
		
		
	}
	
	public void display() {
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setLayout(new BorderLayout());
		
		add(new NorthPanel(), BorderLayout.NORTH);
		add(new CenterPanel(), BorderLayout.CENTER);
		
		setExtendedState(JFrame.MAXIMIZED_BOTH);
		setResizable(false);
		setVisible(true);
		
		Thread playmusic=new playmusic();
		playmusic.start();
	}
	
	public void set() {
		this.game_start = true;
		this.game_stop = false;
		
		this.happy = true;
		this.devil_mode = false;
		this.devil_time = 10;
	}
	
	public void reset() {
		this.set();
		this.game_start = false;
	}
	
	public static void set_MapPanel(JPanel p) {
		map_panel = p;
	}
	
	public void game_stop_dialog() {
		
		
		this.game_stop = true;
		
		int answer = JOptionPane.showOptionDialog(map_panel, "게임을 종료하시겠습니까?", "게임 중지", JOptionPane.YES_NO_CANCEL_OPTION,
				JOptionPane.INFORMATION_MESSAGE, null, TimerPanel.menu, 2);
		
		if(answer == 0) {
			playmusic.clip.stop();
			
			this.reset();
			this.setVisible(false);
			
			LoginFrame.LF = new LoginFrame();
		} 
		else if (answer == 1){  
			playmusic.clip.stop();
			
			this.reset();
			this.setVisible(false);
			
			HomeFrame.HF = new HomeFrame();
		}
		else if (answer == 2) {
			
			this.game_stop = false;
			
		}
		else if (answer == 3) {
			System.exit(0);
		}
		else {
			this.game_stop = false;
		}
	}
	
	public void modifyFile(String id, String oldString, String newString) {
		
		String content = "";
		// System.out.println(LoginEvent.LE.id_list.size());
		
		for (int i = 0; i < LoginEvent.LE.id_list.size(); i += 1) {
			if (LoginEvent.LE.id_list.get(i).equals(id)) {
				content += (LoginEvent.LE.id_list.get(i) + "-" + LoginEvent.LE.pass_list.get(i) + "-" + newString + "\n");
			}
			else {
				content += (LoginEvent.LE.id_list.get(i) + "-" + LoginEvent.LE.pass_list.get(i) + "-" + String.valueOf(LoginEvent.LE.score_list.get(i)) + "\n");
			}
		}
        
		System.out.println(content);
		
		File file = new File("member.txt");
        FileWriter writer = null;
        
        try {
        	// 쓰기 모드로 열어서 txt 파일 초기화
			writer = new FileWriter(file, false);
			writer.write(content);
			
			writer.close();
		} catch (IOException e) {
			
			// TODO Auto-generated catch block
			e.printStackTrace();
			
		}
        
		
    }
	
	
	public void game_finish_dialog() {
		
		playmusic.clip.stop();
		
		this.reset();
		
		int answer = JOptionPane.showOptionDialog(map_panel, "획득한 점수는 " + ScorePanel.score_btn.getText() + "점입니다.", "게임 종료", JOptionPane.YES_NO_CANCEL_OPTION,
				JOptionPane.INFORMATION_MESSAGE, null, Timer_thread.menu, 3);
		
		if (LoginFrame.player.getScore() < Integer.parseInt(ScorePanel.score_btn.getText())) {
			
			// 플레이어 점수 수정
			LoginFrame.player.setScore(Integer.parseInt(ScorePanel.score_btn.getText()));
			
			// 텍스트 파일 수정
			modifyFile(LoginFrame.player.getName(), String.valueOf(LoginFrame.player.getScore()), ScorePanel.score_btn.getText());
		}
		
		if(answer == 0) {
			
			this.setVisible(false);
			
			LoginFrame.LF = new LoginFrame();
		} 
		else if (answer == 1){  
			
			this.setVisible(false);
			
			HomeFrame.HF = new HomeFrame();
		}
		else if (answer == 2) {
			this.setVisible(false);
			
			GameFrame.GF = new GameFrame();
			GameFrame.GF.display();
		}
		else if (answer == 3) {
			System.exit(0);
		}
		else {
			System.exit(0);
		}
	}
	

}
