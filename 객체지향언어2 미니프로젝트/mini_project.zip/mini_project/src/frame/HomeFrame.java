package frame;

import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.LineBorder;

import event.SelectImage;
import frame.HomeFrame.MyPanel;
import music.homemusic;
import thread.Item_thread;
import frame.ExFrame;


public class HomeFrame extends JFrame{
	
	public static HomeFrame HF;
	
	private LineBorder bb = new LineBorder(Color.black, 1, true); 
	
	private MyPanel panel = new MyPanel();
	JLabel la = new JLabel();
	
	public HomeFrame() {
		
		super("게임 준비");
		setSize(850,500);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setContentPane(panel);
		setLayout(null);
		
		
		JButton la = new JButton("물고기 게임");
		la.setFont(new Font("Serif", Font.BOLD, 40));
		//la.setFont(la.getFont().deriveFont(100));
		la.setLocation(270, 20);
		la.setSize(300, 70);
		
		la.setHorizontalAlignment(JLabel.CENTER);
		la.setBackground(Color.orange);
		la.setBorder(bb);
		add(la);
		
		JButton la2 = new JButton("반갑습니다!   " + LoginFrame.LF.player.getName() + "님!");
		la2.setFont(new Font("Serif", Font.BOLD, 20));
		//la.setFont(la.getFont().deriveFont(100));
		la2.setLocation(500, 150);
		la2.setSize(300, 50);
		
		la2.setHorizontalAlignment(JLabel.CENTER);
		la2.setBackground(Color.GREEN);
		la2.setBorder(bb);
		add(la2);
	
		
		//최고 점수 표시
		
		JButton score = new JButton("최고 점수  :  " + String.valueOf(LoginFrame.LF.player.getScore()) + "점");
		score.setFont(new Font("Serif", Font.BOLD, 20));
		//la.setFont(la.getFont().deriveFont(100));
		score.setLocation(500, 230);
		score.setSize(300, 50);
		
		score.setHorizontalAlignment(JLabel.CENTER);
		score.setBackground(Color.yellow);
		score.setBorder(bb);
		add(score);
		
		
		JLabel image = new JLabel(LoginFrame.LF.player.get_Image());
		image.setLocation(60, 120);
		image.setSize(200, 200);
		add(image);
		
		
		JButton nextBtn = new JButton("게임 시작!");
		nextBtn.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
					homemusic.clip.stop();
				
					setVisible(false);
					GameFrame.GF = new GameFrame();
					GameFrame.GF.display();
			}
		});
		nextBtn.setSize(100, 50);
		nextBtn.setLocation(600, 380);
		add(nextBtn);
		
		
		JButton nextBtn2 = new JButton("가이드북");
		nextBtn2.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
					setVisible(false);
					ExFrame.ExF = new ExFrame();
			}
		});
		nextBtn2.setSize(100, 50);
		nextBtn2.setLocation(720, 380);
		add(nextBtn2);
		
		JButton nextBtn3 = new JButton("로그인 화면으로");
		nextBtn3.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
					homemusic.clip.stop();
				
					setVisible(false);
					LoginFrame.LF = new LoginFrame();
			}
		});
		
		nextBtn3.setSize(130, 50);
		nextBtn3.setLocation(30, 380);
		add(nextBtn3);
		
		setLocationRelativeTo(null);
		setVisible(true);
		
		Thread homemusic = new homemusic();
		homemusic.start();
	}

	class MyPanel extends JPanel {
		ImageIcon backgroundicon = new ImageIcon(getClass().getClassLoader().getResource("sea.jpg"));
		Image background = backgroundicon.getImage();
		
		public void paintComponent(Graphics g) {
			super.paintComponent(g);
			
			// 이미지를 패널 크기로 조절하여 그린다
			g.drawImage(background, 0, 0, getWidth(), getHeight(), this);
		}	
	}
}
