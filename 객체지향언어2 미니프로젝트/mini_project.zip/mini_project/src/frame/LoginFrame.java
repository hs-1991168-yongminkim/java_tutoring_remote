package frame;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseListener;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;

import javax.swing.*;
import javax.swing.border.LineBorder;

import event.LoginEvent;
import event.MouseClick;
import event.SelectImage;
import object.Player;
import panel.CenterPanel;
import panel.NorthPanel;

public class LoginFrame extends JFrame {
	
	public static LoginFrame LF;
	public static Player player;
	
	private LineBorder bb = new LineBorder(Color.black, 1, true); 
	
	public String[] image_link_arr = {"turtle.png", "pikacu.png", "pink_animal.png", "ball.png"};
	public ImageIcon[] icon_arr = new ImageIcon[image_link_arr.length];
	public ImageIcon[] icon_arr_change = new ImageIcon[image_link_arr.length];
	
	public String[] sel_image_link_arr = {"select_turtle.png", "select_pikacu.png", "select_pink_animal.png", "select_ball.png"};
	public ImageIcon[] sel_icon_arr = new ImageIcon[sel_image_link_arr.length];
	public ImageIcon[] sel_icon_arr_change = new ImageIcon[sel_image_link_arr.length];
	
	public JLabel[] label_image_list = new JLabel[image_link_arr.length];
	public boolean[] is_selected_arr = {false, false, false, false};
	
	int image_len = 100;
	
	
	public LoginFrame()
	{
		super("로그인 창");
		
		setLayout(null);
		getContentPane().setBackground(new Color(255, 251, 234));
		
		JButton la = new JButton("물고기 게임");
		la.setHorizontalAlignment(JLabel.CENTER);
		la.setFont(new Font("Serif", Font.BOLD, 30));
		la.setForeground(Color.black);
		la.setBackground(Color.orange);
		la.setBorder(bb);
		
		//la.setFont(la.getFont().deriveFont(100));
		
		la.setLocation(140, 10);
		la.setSize(200, 50);
		add(la);
		
		
		for (int i = 0; i < image_link_arr.length; i += 1) {
			icon_arr[i] = new ImageIcon(getClass().getClassLoader().getResource((image_link_arr[i])));
			
			Image img = icon_arr[i].getImage();
			Image changeImg = img.getScaledInstance(image_len, image_len, Image.SCALE_DEFAULT);
			
			icon_arr_change[i] = new ImageIcon(changeImg);
			
			
			sel_icon_arr[i] = new ImageIcon(getClass().getClassLoader().getResource((sel_image_link_arr[i])));
			
			Image sel_img = sel_icon_arr[i].getImage();
			Image sel_changeImg = sel_img.getScaledInstance(image_len, image_len, Image.SCALE_DEFAULT);
			
			sel_icon_arr_change[i] = new ImageIcon(sel_changeImg);
		}
		
		
		JLabel id = new JLabel("아이디");
		id.setFont(new Font("Serif", Font.BOLD, 15));
		id.setLocation(120, 220);
		id.setSize(100, 31);
		add(id);
		
	
		JTextField id_text = new JTextField("");
		id_text.setLocation(210, 220);
		id_text.setSize(140, 30);
		add(id_text);
		
		
		JLabel pass = new JLabel("비밀번호");
		pass.setFont(new Font("Serif", Font.BOLD, 15));
		pass.setLocation(120, 270);
		pass.setSize(100, 31);
		add(pass);
		
	
		JTextField pass_text = new JTextField("");
		pass_text.setLocation(210, 270);
		pass_text.setSize(140, 30);
		add(pass_text);
		
		
		JLabel image = new JLabel("이미지");
		image.setFont(new Font("Serif", Font.BOLD, 15));
		image.setLocation(120, 320);
		image.setSize(100, 31);
		add(image);
		
	
		JTextField image_text = new JTextField("");
		image_text.setLocation(210, 320);
		image_text.setSize(140, 30);
		image_text.setEnabled(false);
		add(image_text);
		
		
		// 조회 결과 알려줌
		JLabel message = new JLabel("");
		message.setLocation(170, 360);
		message.setSize(300, 30);
		add(message);
		
		
		label_image_list[0] = new JLabel(icon_arr_change[0]);
		label_image_list[0].setLocation(40, 75);
		label_image_list[0].setSize(100, 100);
		label_image_list[0].addMouseListener(new SelectImage(0, "turtle.png", image_text));
		add(label_image_list[0]);
		
		
		label_image_list[1] = new JLabel(icon_arr_change[1]);
		label_image_list[1].setLocation(140, 80);
		label_image_list[1].setSize(100, 100);
		label_image_list[1].addMouseListener(new SelectImage(1, "pikacu.png", image_text));
		add(label_image_list[1]);
		
		
		label_image_list[2] = new JLabel(icon_arr_change[2]);
		label_image_list[2].setLocation(240, 80);
		label_image_list[2].setSize(100, 100);
		label_image_list[2].addMouseListener(new SelectImage(2, "pink_animal.png", image_text));
		add(label_image_list[2]);
		
		
		label_image_list[3] = new JLabel(icon_arr_change[3]);
		label_image_list[3].setLocation(340, 80);
		label_image_list[3].setSize(100, 100);
		label_image_list[3].addMouseListener(new SelectImage(3, "ball.png", image_text));
		add(label_image_list[3]);
		
		
		
		JButton play = new JButton("login");
		play.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					
					// 정보 새로고침
					LoginEvent.LE.set_data();
					
					if (LoginEvent.LE.is_Possible_Login(id_text.getText(), pass_text.getText()) == true) {
						if (image_text.getText().length() > 0) {
							setVisible(false);
							
							player = new Player(id_text.getText(), image_text.getText());
							HomeFrame.HF = new HomeFrame();
						}
						else {
							message.setText("이미지를 선택해야 합니다.");
						}
						
					}
					else {
						message.setText("아이디나 패스워드가 일치하지 않습니다");
					}
					
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		
		play.setLocation(120, 400);
		play.setSize(80, 30);
		add(play);
		
		
		JButton join = new JButton("회원가입");
		join.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				
				
				File file = new File("member.txt");
				
				String id_str = id_text.getText();
				String pass_str = pass_text.getText();
				String score_str = "0";

				String str = id_str + "-" + pass_str + "-" + score_str + "\n";
				try {
					if (LoginEvent.LE.is_Possible_join(id_text.getText()) == true) {
						message.setText("이미 가입되어 있습니다.");
					}
					else {
						if (id_text.getText().length() > 0 && pass_text.getText().length() > 0) {
							// BufferedWriter writer = new BufferedWriter(new FileWriter(file, true));
							
							// 기존 정보에서 추가하는 모드
							BufferedWriter writer = new BufferedWriter(new FileWriter(file, true));
						    writer.write(str);
						    
						    message.setText("회원가입이 완료되었습니다.");
						    
						    // 정보 새로 고침
						    LoginEvent.LE.set_data();
						    
						    writer.close();
						}
						else {
							message.setText("아이디나 비밀번호를 입력해야 합니다.");
						}
					}
					
				    
				    
				} catch (IOException io_e) {
					io_e.printStackTrace();
				}
			}
		});
		
		join.setLocation(270, 400);
		join.setSize(100, 30);
		add(join);
		
		
		setSize(500, 500);
		
		
		// locationRelativeTo는 setSize 밑에 있어야 한다
		setLocationRelativeTo(null);
		setVisible(true);
	}

	public static void main(String[] args) {
		LF = new LoginFrame();
	}

}
