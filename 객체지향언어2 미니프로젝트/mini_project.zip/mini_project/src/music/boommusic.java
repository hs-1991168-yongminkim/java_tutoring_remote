package music;

import java.awt.Color;
import java.awt.Container;
import java.awt.FlowLayout;
import java.io.File;
import java.io.IOException;
import java.net.URL;

import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.LineEvent;
import javax.sound.sampled.LineListener;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;
import javax.swing.JFrame;

public class boommusic extends Thread{
	
	public static Clip clip;
	private String song = "boom.wav";
	
	URL SoundURL = getClass().getClassLoader().getResource(song);
	
	
	
	
	public boommusic()
	{
		
	}
	
	public void run()
	{
		loadAudio(SoundURL);
	}
	
	
	private void loadAudio(URL pathName) {
		try {
			
			final AudioInputStream audioStream = AudioSystem.getAudioInputStream(pathName); 
			
			clip = AudioSystem.getClip(); // 비어있는 오디오 클립 만들기
			clip.open(audioStream); // 재생할 오디오 스트림 열기
			clip.start(); // 재생 시작
		}
		catch (LineUnavailableException e) { e.printStackTrace(); }
		catch (UnsupportedAudioFileException e) { e.printStackTrace(); }
		catch (IOException e) { e.printStackTrace(); }
	}
}