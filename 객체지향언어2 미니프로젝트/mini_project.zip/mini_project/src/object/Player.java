package object;

import java.awt.Image;

import javax.swing.ImageIcon;

import event.LoginEvent;

public class Player {

	private String name;
	private String imageLink;
	private int score;
	
	private ImageIcon icon;
	private int image_size = 200;
	
	public Player(String name, String imageLink) {
		this.name = name;
		this.imageLink = imageLink;
		
		int index = LoginEvent.LE.id_list.indexOf(name);
		this.score = LoginEvent.LE.score_list.get(index);
		
		this.icon = new ImageIcon(getClass().getClassLoader().getResource((imageLink)));
		make_Image();
	}
	
	public void make_Image() {
		Image img = icon.getImage();
		Image changeImg = img.getScaledInstance(image_size, image_size, Image.SCALE_DEFAULT);
		
		icon = new ImageIcon(changeImg);
	}
	
	public ImageIcon get_Image() {
		return this.icon;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public String getName() {
		return this.name;
	}
	
	public void setImageLink(String imageLink) {
		this.imageLink = imageLink;
	}
	
	public String getImageLink() {
		return this.imageLink;
	}
	
	public void setScore(int s) {
		this.score = s;
	}
	
	public int getScore() {
		return this.score;
	}
}
