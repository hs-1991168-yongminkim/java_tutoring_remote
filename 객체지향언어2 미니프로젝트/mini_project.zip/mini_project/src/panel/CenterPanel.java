package panel;

import java.awt.Color;
import java.awt.GridLayout;

import javax.swing.BorderFactory;
import javax.swing.JPanel;

import frame.GameFrame;
import thread.Item_thread;
import thread.Timer_thread;

public class CenterPanel extends JPanel {
	
	public CenterPanel() {
		
		setBorder(BorderFactory.createEmptyBorder(20 , 20 , 20 , 20));
		
		setBackground(Color.WHITE);
		
		setLayout(new GridLayout(1, 1, 100, 100)); 
		
		
		MapPanel mp = new MapPanel();
		GameFrame.set_MapPanel(mp);
		add(mp);
		
		Thread item_th = new Item_thread(mp);
		item_th.start();
		
		try {  
			Thread.sleep(200);
		}
		catch(Exception e) {
			System.out.println(e);
		}
		
		Thread time_th = new Timer_thread(mp);
		time_th.start();
		
	}
	
}