package panel;
import java.awt.GridLayout;

import javax.swing.JLabel;
import javax.swing.JPanel;

import object.Player;


public class MapPanel extends JPanel {
	
	private int map_len = 20;
	
	
	private JLabel[][] label_Arr = new JLabel[map_len][map_len]; 
	
	public MapPanel() {
		
		setLayout(new GridLayout(map_len, map_len, 3, 3));
		setOpaque(true); 
		
	}
	

	public JLabel[][] getLabel_Arr() {
		return this.label_Arr;
	}

}
