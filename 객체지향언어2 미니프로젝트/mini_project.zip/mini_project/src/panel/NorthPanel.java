package panel;
import java.awt.Color;
import java.awt.GridLayout;

import javax.swing.JPanel;

public class NorthPanel extends JPanel {
	public NorthPanel() {
		setOpaque(true);
		
		setBackground(Color.LIGHT_GRAY);
		// setBackground(new Color(255, 251, 234));
		
		setLayout(new GridLayout(1, 3, 100, 0));	
		
		add(new PlayerStatusPanel());
		add(new TimerPanel());
		add(new ScorePanel());
		
	}
}