package panel;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Image;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import event.SelectImage;
import frame.LoginFrame;
import thread.Set_character_thread;

public class PlayerStatusPanel extends JPanel {
	
	public PlayerStatusPanel() {
		
		
		setLayout(new FlowLayout(FlowLayout.CENTER, 20, 10));
		setBackground(new Color(255, 251, 234));
		
		
		ImageIcon before = new ImageIcon(getClass().getClassLoader().getResource((LoginFrame.player.getImageLink())));
		
		Image img = before.getImage();
		Image changeImg = img.getScaledInstance(80, 100, Image.SCALE_DEFAULT);
		
		ImageIcon after = new ImageIcon(changeImg);
		
		JLabel player_image = new JLabel(after);
		player_image.setLocation(20, 20);
		player_image.setSize(50, 50);
		add(player_image);
		
	
		JButton id_text = new JButton("이름 : " + LoginFrame.player.getName());
		// id_text.setFont(new Font("Arial", Font.BOLD, 20));
		id_text.setLocation(140, 50);
		id_text.setPreferredSize(new Dimension(150, 30));
		id_text.setBackground(Color.white);
		
		// id_text.setEnabled(false);
		add(id_text);
		
		
	
		JButton score_text = new JButton("최고 점수 : " + String.valueOf(LoginFrame.player.getScore()));
		// id_text.setFont(new Font("Arial", Font.BOLD, 20));
		score_text.setLocation(140, 50);
		score_text.setPreferredSize(new Dimension(150, 30));
		score_text.setBackground(Color.pink);
		
		// id_text.setEnabled(false);
		add(score_text);
		
		Thread setimg = new Set_character_thread(player_image);
		setimg.start();
	}
}