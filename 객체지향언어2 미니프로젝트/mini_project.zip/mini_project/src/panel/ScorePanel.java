package panel;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JPanel;

public class ScorePanel extends JPanel {
	
	public static JButton score_btn;
	public static JButton shield_btn;
	public static JButton state_btn;
	
	public ScorePanel() {
		setLayout(new FlowLayout(FlowLayout.CENTER, 20, 10)); 
		
		setBackground(new Color(255, 251, 234));
		
		JButton score = new JButton("점수"); 
		
		score.setPreferredSize(new Dimension(160, 25));
		score.setBackground(Color.white);
		add(score);
		
		
		score_btn = new JButton("0"); 
		score_btn.setPreferredSize(new Dimension(160, 25));
		score_btn.setBackground(Color.cyan);
		add(score_btn); 
		
		
		JButton shield = new JButton("방패 개수"); 
		
		shield.setPreferredSize(new Dimension(160, 25));
		shield.setBackground(Color.white);
		add(shield);
		
		
		shield_btn = new JButton("0"); 
		// heal_btn.setEnabled(false);
		shield_btn.setPreferredSize(new Dimension(160, 25));
		shield_btn.setBackground(Color.cyan);
		add(shield_btn); 
		
		
		JButton state = new JButton("상태"); 
		// 크기가 너무 크면 eventQueue에서 오류 발생(실행하는데는 문제 없다)
		state.setPreferredSize(new Dimension(160, 25));
		state.setBackground(Color.white);
		add(state);
		
		
		state_btn = new JButton("정상"); 
		// heal_btn.setEnabled(false);
		state_btn.setPreferredSize(new Dimension(160, 25));
		state_btn.setBackground(Color.cyan);
		add(state_btn); 
	}
}

