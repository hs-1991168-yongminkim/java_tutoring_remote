package panel;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

import frame.GameFrame;
import frame.HomeFrame;
import frame.LoginFrame;
import thread.Item_thread;
import thread.Timer_thread;

public class TimerPanel extends JPanel {

	public static JButton time_btn;
	public static String[] menu = {"로그인", "홈", "게임 재개", "종료"};
	
	public TimerPanel() {
		// 가운데 정렬, 좌우 간격 20, 상하 간격 10
		setLayout(new FlowLayout(FlowLayout.CENTER)); 
		
		setBackground(new Color(255, 251, 234));
		
		time_btn = new JButton(""); 
		time_btn.setPreferredSize(new Dimension(300, 50));
		
		time_btn.setFont(new Font("Serif", Font.BOLD, 40));
		time_btn.setBackground(Color.yellow);
		add(time_btn); 
		
		JButton stopbnt = new JButton("STOP");
		stopbnt.setFont(new Font("Serif", Font.BOLD, 20));
		stopbnt.setPreferredSize(new Dimension(300, 50));
		stopbnt.addActionListener(new ActionListener() {
			// stop을 누르면 로그인 화면, 홈 화면, 게임 재개, 종료 다이얼로그 생성
			@Override
			public void actionPerformed(ActionEvent e) {
				
				GameFrame.GF.game_stop_dialog();
			}
		});
		add(stopbnt);
	}
}
