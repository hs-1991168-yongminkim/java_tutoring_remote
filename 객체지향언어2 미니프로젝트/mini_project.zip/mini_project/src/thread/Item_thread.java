package thread;

import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.util.ArrayList;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;

import event.MouseClick;
import frame.GameFrame;

public class Item_thread extends Thread{
	
	public static JLabel[][] label_arr = new JLabel[20][20];
	
	private int image_len = 55;
	
	private String[] image_link_arr = {"fish.png", "tornado.png", "devil.png", "shield.png", "bomb.png"};

	ImageIcon[] icon_arr;
	
	ImageIcon[] icon_arr_change;
	
	private JPanel panel;
	
	public Item_thread(JPanel panel){

		this.panel = panel;
		
		icon_arr = new ImageIcon[image_link_arr.length];
		icon_arr_change = new ImageIcon[image_link_arr.length];
	}
	
	public void run() {
		
		
		for (int i = 0; i < image_link_arr.length; i += 1) {
			icon_arr[i] = new ImageIcon(getClass().getClassLoader().getResource((image_link_arr[i])));
			
			Image img = icon_arr[i].getImage();
			Image changeImg = null;
			
			if (i == 0) {
				changeImg = img.getScaledInstance(image_len, image_len, Image.SCALE_DEFAULT);
			}
			else if (i == 1) {
				changeImg = img.getScaledInstance(image_len - 5, image_len - 18, Image.SCALE_DEFAULT);
			}
			else if (i == 2) {
				changeImg = img.getScaledInstance(image_len - 10, image_len - 17, Image.SCALE_DEFAULT);
			}
			else if (i == 3) {
				changeImg = img.getScaledInstance(image_len - 5, image_len - 15, Image.SCALE_DEFAULT);
			}
			else if (i == 4) {
				changeImg = img.getScaledInstance(image_len - 5, image_len - 7, Image.SCALE_DEFAULT);
			}
			
			icon_arr_change[i] = new ImageIcon(changeImg);
		}
		
		
		for(int i=0; i < 20; i++)
		{
			for(int j=0; j < 20; j++)
			{
				
				label_arr[i][j] = new JLabel("_");
				
				// 글자 크기 0으로 설정
				Font myFont1 = new Font("Serif", Font.BOLD, 0);
				label_arr[i][j].setFont(myFont1);
				
				label_arr[i][j].setSize(10, 10);
				label_arr[i][j].setOpaque(true);
				label_arr[i][j].setBackground(Color.white);
				
				
				label_arr[i][j].setForeground(Color.white);
				
				
				label_arr[i][j].addMouseListener(new MouseClick());
				panel.add(label_arr[i][j]);
				
			}
		}
		
		
		while(true) { 
			
			// 종료 조건 : 로그인 화면으로 이동, 홈 화면으로 이동, 게임 다시 시작
			if (GameFrame.GF.get_game_start() == false) {
				System.out.println("finish | item");
				return;
			}
			
			else {
				
				// 게임 정지 상태이면
				if (GameFrame.GF.get_game_stop() == true) {
					System.out.println("time_stop : true | item");
					while (GameFrame.GF.get_game_stop() == true) {
						// 비워두면 오류가 발생
						System.out.println("IIII");
						
					}
					System.out.println("time_stop : false | item");
					continue;
				}
				
				int x = (int)(Math.random() * 20);
				int y = (int)(Math.random() * 20);
				int randomitem=(int)(Math.random() * 100);
				
				if(randomitem >= 90)  
				{	
					label_arr[y][x].setIcon(icon_arr_change[0]);
					label_arr[y][x].setHorizontalAlignment(JLabel.CENTER);
					label_arr[y][x].setText("f");
				}
				else if(randomitem >= 85) 
				{
					label_arr[y][x].setIcon(icon_arr_change[1]);
					label_arr[y][x].setHorizontalAlignment(JLabel.CENTER);
					label_arr[y][x].setText("t");
				}
				else if(randomitem >= 80)  
				{
					label_arr[y][x].setIcon(icon_arr_change[2]);
					label_arr[y][x].setHorizontalAlignment(JLabel.CENTER);
					label_arr[y][x].setText("d");
				}
				else if(randomitem >= 75)  
				{
					label_arr[y][x].setIcon(icon_arr_change[3]);
					label_arr[y][x].setHorizontalAlignment(JLabel.CENTER);
					label_arr[y][x].setText("s");
				}
				else  
				{
					label_arr[y][x].setIcon(icon_arr_change[4]);
					label_arr[y][x].setHorizontalAlignment(JLabel.CENTER);
					label_arr[y][x].setText("b");
				}
				
				panel.setBackground(Color.pink);
				panel.setVisible(true);
				
				try {  
					sleep(150);
				}
				catch(Exception e) {
					System.out.println(e);
				}
				
			}
			
			
		}
	}
}


