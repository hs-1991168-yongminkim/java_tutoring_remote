package thread;

import java.awt.Image;

import javax.swing.ImageIcon;
import javax.swing.JLabel;
import event.MouseClick;
import frame.GameFrame;
import frame.LoginFrame;

public class Set_character_thread extends Thread{
	
	private JLabel label;

	private int image_len = 100;
	private String image_link = LoginFrame.LF.player.getImageLink();
	
	private String[] image_link_arr = {image_link, "sad_" + image_link, "devil_" + image_link};
	
	ImageIcon[] icon_arr = new ImageIcon[image_link_arr.length];
	
	ImageIcon[] icon_arr_change = new ImageIcon[image_link_arr.length];
	
	
	public Set_character_thread(JLabel label){
		this.label=label;
		
		for (int i = 0; i < image_link_arr.length; i += 1) {
			icon_arr[i] = new ImageIcon(getClass().getClassLoader().getResource((image_link_arr[i])));
			
			Image img = icon_arr[i].getImage();
			Image changeImg = null;
			
			changeImg = img.getScaledInstance(image_len, image_len, Image.SCALE_DEFAULT);
			
			icon_arr_change[i] = new ImageIcon(changeImg);
		}
	}
	
	public void run() {
		
		while(true) {
			
			// 게임 종료되면 종료
			// 중지 중이면 그대로 진행
			if (GameFrame.GF.get_game_start() == false) {
				return;
			}
			
			//데빌 모드면 데빌 이미지 설정
			if(GameFrame.GF.get_devil_mode() == true) {
				label.setIcon(icon_arr_change[2]);
			}
			
			else  //데빌 모드가 아니면
			{
				if(GameFrame.GF.get_happy() == true) { //물고기 먹으면
					label.setIcon(icon_arr_change[0]);
				}
				else {
						label.setIcon(icon_arr_change[1]);
				}
					
			}
		}
			
	}

}
