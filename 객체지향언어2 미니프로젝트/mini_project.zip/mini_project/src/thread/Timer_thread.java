package thread;

import java.awt.Color;

import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

import frame.GameFrame;
import frame.HomeFrame;
import frame.LoginFrame;
import music.playmusic;
import panel.ScorePanel;
import panel.TimerPanel;

public class Timer_thread extends Thread {
	
	public static String[] menu = {"로그인", "홈", "다시 시작", "종료"};
	
	public int second;
	private JPanel panel;

	
	public Timer_thread(JPanel panel) {
		second = 10 + 1;
		this.panel = panel;
	}

	@Override
	public void run() {
		
		while (true) {
			
			// 종료 조건 : 로그인 화면으로 이동, 홈 화면으로 이동, 게임 다시 시작
			if (GameFrame.GF.get_game_start() == false) {
				System.out.println("finish");
				return;
			}
			
			// 게임 종료되지 않음
			else {
				
				//  정지 조건 : stop 버튼 누를 시
				if (GameFrame.GF.get_game_stop() == true) {
					System.out.println("time_stop : true");
					while (GameFrame.GF.get_game_stop() == true) {
						// 비워두면 오류가 발생
						System.out.println("TTTT");
						
					}
					System.out.println("time_stop : false");
					continue;
				}
				
				// 게임 진행 중이고 시간 다 됐을 때
				else if (second == 0) {
					
					GameFrame.GF.game_finish_dialog();
					return;
				}
				
				else if (second > 0) {
					
					if (GameFrame.GF.get_devil_mode() == true) {
						if (GameFrame.GF.get_devil_time() > 0) {
							GameFrame.GF.set_devil_time(GameFrame.GF.get_devil_time() - 1);
							TimerPanel.time_btn.setForeground(Color.RED);
						}
						else {
							GameFrame.GF.set_devil_mode(false);
							ScorePanel.state_btn.setForeground(Color.black);
							ScorePanel.state_btn.setText("정상");
							
							TimerPanel.time_btn.setForeground(Color.black);
						}
					}
					second -= 1;
					TimerPanel.time_btn.setText(String.valueOf(second));
					
				} 
				
				if (second == 0) {
					GameFrame.GF.game_finish_dialog();
					return;
				}
				
				try {
					Thread.sleep(1000);	
				} catch (Exception e) {
					e.printStackTrace();
				}
				
			}
			
			
		}
		
		
	}
}
